$(document).ready(function () { 
$(".Music-Btn").click(function(){

if(!$(".Music-Btn").hasClass("song-opened")){
$("#song").css("display","block");  
$(this).addClass("song-opened");  
}

else{   
$("#song").css("display","none");  
$(".Music-Btn").removeClass("song-opened");  
}
})

$(document).on('click', 'a[href^="#"]', function (event) {
event.preventDefault();

$('html, body').animate({
scrollTop: $($.attr(this, 'href')).offset().top - 210
}, 800);
});

$('.ml2').each(function(){
$(this).html($(this).text().replace(/([^\x00-\x80]|\w)/g, "<span class='letter'>$&</span>"));
});

anime.timeline({loop: true})
.add({
targets: '.ml2 .letter',
translateX: [40,0],
translateZ: 0,
opacity: [0,1],
easing: "easeOutExpo",
duration: 1200,
delay: function(el, i) {
return 500 + 30 * i;
}
}).add({
targets: '.ml2 .letter',
translateX: [0,-30],
opacity: [1,0],
easing: "easeInExpo",
duration: 1100,
delay: function(el, i) {
return 100 + 30 * i;
}
});

$(window).load(function(){
$(".ml2 .letter").fadeOut(7000,function(){
$(".preloader").fadeOut(650);
})
})

$(".color-choose").click(function(){
if(!$(".colors").hasClass("open")){    
$(".colors").animate({
left : "0px"
},450,function(){
$(".colors").addClass("open");
$(".colors").css("box-shadow","1px 1px 4px rgb(144, 144, 144)");
$(".color-choose").css("box-shadow","1px 1px 4px rgb(144, 144, 144)");
})
}else{
$(".colors").animate({
left : "-200px"
},450,function(){
$(".colors").removeClass("open");
$(".colors").css("box-shadow","none");
$(".color-choose").css("box-shadow","none");
})
}
})

$(".first-color").click(function(){
$(".navbar-brand").css("color","rgb(181, 21, 76)");
$(".fa-heart").css("color","rgb(181, 21, 76)");
$("headline").css("text-shadow","1px 1px 1px rgb(181, 21, 76)");
$(".wedding_time").css("color","rgb(181, 21, 76)");
$(".friend-name").css("color","rgb(181, 21, 76)");
$("footer").css("background-color","rgb(181, 21, 76)");
})

$(".second-color").click(function(){
$(".navbar-brand").css("color","rgb(249, 188, 196)");
$(".fa-heart").css("color","rgb(249, 188, 196)");
$("headline").css("text-shadow","1px 1px 1px rgb(249, 188, 196)");
$(".wedding_time").css("color","rgb(249, 188, 196)");
$(".friend-name").css("color","rgb(249, 188, 196)");
$("footer").css("background-color","rgb(249, 188, 196)");
})

$(".third-color").click(function(){
$(".navbar-brand").css("color","rgb(221, 158, 168)");
$(".fa-heart").css("color","rgb(221, 158, 168)");
$("headline").css("text-shadow","1px 1px 1px rgb(221, 158, 168)");
$(".wedding_time").css("color","rgb(221, 158, 168)");
$(".friend-name").css("color","rgb(221, 158, 168)");
$("footer").css("background-color","rgb(221, 158, 168)");
})

$(".fourth-color").click(function(){
$(".navbar-brand").css("color","rgb(149, 83, 127)");
$(".fa-heart").css("color","rgb(149, 83, 127)");
$("headline").css("text-shadow","1px 1px 1px rgb(149, 83, 127)");
$(".wedding_time").css("color","rgb(149, 83, 127)");
$(".friend-name").css("color","rgb(149, 83, 127)");
$("footer").css("background-color","rgb(149, 83, 127)");
})

$(".fifth-color").click(function(){
$(".navbar-brand").css("color","rgb(75, 0, 0)");
$(".fa-heart").css("color","rgb(75, 0, 0)");
$("headline").css("text-shadow","1px 1px 1px rgb(75, 0, 0)");
$(".wedding_time").css("color","rgb(75, 0, 0)");
$(".friend-name").css("color","rgb(75, 0, 0)");
$("footer").css("background-color","rgb(75, 0, 0)");
})

$(".sixth-color").click(function(){
$(".navbar-brand").css("color","rgb(116, 47, 53)");
$(".fa-heart").css("color","rgb(116, 47, 53)");
$("headline").css("text-shadow","1px 1px 1px rgb(116, 47, 53)");
$(".wedding_time").css("color","rgb(116, 47, 53)");
$(".friend-name").css("color","rgb(116, 47, 53)");
$("footer").css("background-color","rgb(116, 47, 53)");
});
    
});

mixitup('#mix-wrapper', {
	animation: {
    effects: 'fade',
    duration: 700
  },
  classNames: {
    block: 'gallery-buttons',
    elementFilter: 'filter-button',
    elementSort: 'sort-btn'
  },
  selectors: {
    target: '.mix-target'
  }
});

function makeTimer() {

var endTime = new Date("August 20, 2019 12:00:00 PDT");			
var endTime = (Date.parse(endTime)) / 1000;

var now = new Date();
var now = (Date.parse(now) / 1000);

var timeLeft = endTime - now;

var days = Math.floor(timeLeft / 86400); 
var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));

if (hours < "10") { hours = "0" + hours; }
if (minutes < "10") { minutes = "0" + minutes; }
if (seconds < "10") { seconds = "0" + seconds; }

$("#days").html(days + "<span class = 'time'><br>Days</span>");
$("#hours").html(hours + "<span class = 'time'><br>Hours</span>");
$("#minutes").html(minutes + "<span class = 'time'><br>Minutes</span>");
$("#seconds").html(seconds + "<span class = 'time'><br>Seconds</span>");		

}

setInterval(function() { makeTimer(); }, 1000);